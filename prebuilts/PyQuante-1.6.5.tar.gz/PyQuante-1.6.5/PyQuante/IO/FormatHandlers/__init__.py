from HandlerList import HandlerList # utility

import XYZ
import CML


format_handlers= HandlerList(XYZ.Handler, CML.Handler)
