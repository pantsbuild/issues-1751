"""\

NAME
      pressure.py

SYNOPSIS
      PyQuante module for applying pressure in electronic structure methods.
      The method is based off of 
      Cococcioni, Mauri, Ceder, and Marzari. PRL 94 145501


DESCRIPTION
	  
AUTHOR
      Hatem H. Helal, hhh23@cam.ac.uk

REPORT BUGS
      Report bugs to hhh23@cam.ac.uk

COPYRIGHT

"""
#from PyQuante.Ints import getbasis
#import os

#def threshold():


#def quantum_volume(D):


