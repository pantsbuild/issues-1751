"""\
Defaults.py - PyQuante-wide program defaults.
"""
# Everything in this module was moved to settings.py
