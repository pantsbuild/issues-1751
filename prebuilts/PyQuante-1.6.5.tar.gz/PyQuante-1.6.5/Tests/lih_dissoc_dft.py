#!/usr/bin/env python
from lih_dft import dissoc
dissoc()
