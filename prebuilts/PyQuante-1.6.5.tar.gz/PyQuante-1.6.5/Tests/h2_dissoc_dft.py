#!/usr/bin/env python
from h2_dft import dissoc
dissoc()
