#!/usr/bin/env python

from UnitSweet import runsuite

runsuite()


